package com.service;

import java.util.List;

import com.model.Employee;

public interface EmployeeServiceInterface 

{
	public Employee saveEmployee(Employee e);//for saving single record
	
	
	public List<Employee> saveAllEmployee(List<Employee> list);//java.util//for saving list of record
	
	public  Employee getOneEmployee(int id);
	
	public  List<Employee> getAllEmployee();

	public void deleteById(int id);
	
	public Employee updateEmployee(Employee e);
	
	public Employee getfindByEmail(String email);

	public List<String> findEmployeeNames();

	
}
