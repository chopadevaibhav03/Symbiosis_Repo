package com.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;

import com.model.Employee;

@Repository

public interface EmployeeRepository extends JpaRepository<Employee,Integer>
{
	// for "field(has getter and setter)" city findByCity
	
	Employee findByEmail(String email);  //for finding email(field)
	

	@Query("Select name from Employee ")
	List<String> findEmployeeNames();
	
}
