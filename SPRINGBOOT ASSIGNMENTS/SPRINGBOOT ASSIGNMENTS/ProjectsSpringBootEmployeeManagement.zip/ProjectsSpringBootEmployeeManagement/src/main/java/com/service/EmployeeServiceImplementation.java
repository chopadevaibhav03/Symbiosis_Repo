package com.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.exception.NoSuchEmployeeException;
import com.model.Employee;
import com.repository.EmployeeRepository;

@Service
public class EmployeeServiceImplementation implements EmployeeServiceInterface
{
	@Autowired
	EmployeeRepository empRepo;
	
	@Override
	public Employee saveEmployee(Employee e)
	{
		empRepo.save(e);
		return e;
	}

	@Override
	public List<Employee> saveAllEmployee(List<Employee> list) 
	{
		empRepo.saveAll(list);
		return list;
	}

//	//without EXCEPTION
//	@Override
//	public  Employee getOneEmployee(int id)
//	{
//		return empRepo.findById(id).orElse(null);
//
//	}
	
	
	@Override
	public  Employee getOneEmployee(int id)
	{
		return empRepo.findById(id).orElseThrow(

				()-> new NoSuchEmployeeException("Employee Not Found Exception of id "+ id)
				);

	}

	@Override
	public List<Employee> getAllEmployee() 
	{
		return empRepo.findAll();
	}

	@Override
	public void deleteById(int id) 
	{

		empRepo.deleteById(id);
	}

	@Override
	public Employee updateEmployee(Employee e) 
	{
		
		Employee existsEmployee =empRepo.findById(e.getId()).orElse(null);
		existsEmployee.setName(e.getName());
		return empRepo.save(existsEmployee);
		
	}

	
	@Override
	public Employee getfindByEmail(String email) 
	{
		return empRepo.findByEmail(email);
	}

	@Override
	public List<String> findEmployeeNames()
	{		
		return empRepo.findEmployeeNames();

	}

	
	

	
	
}
