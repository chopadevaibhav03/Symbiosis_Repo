package com.exception;

public class NoSuchEmployeeException extends RuntimeException
{

	String s;
	public NoSuchEmployeeException(String s)
	{
		super(s);
		this.s=s;
		System.out.println(s);
		
	}
}
