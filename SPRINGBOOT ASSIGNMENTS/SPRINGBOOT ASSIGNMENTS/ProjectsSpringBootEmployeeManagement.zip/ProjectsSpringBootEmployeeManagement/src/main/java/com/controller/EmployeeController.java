package com.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.model.Employee;
import com.service.EmployeeServiceInterface;

@RestController

public class EmployeeController 
{
	@Autowired
	EmployeeServiceInterface empService;
	
//	@PostMapping("add.")//method name can be different becuz it calls mapping (" ")
//	
//	
//	public Employee addEmployee(@RequestBody Employee e)
//	{
//		empService.saveEmployee(e);
//		return e;
//	}
	
	//2nd method to add records 
	@PostMapping("add")
	
	public ResponseEntity<Employee> addEmployee(@RequestBody Employee e)
	{
		Employee emp = empService.saveEmployee(e);
		return ResponseEntity.status(HttpStatus.CREATED).header("add", "save Employee").body(emp);
	}
	
	//@RequestBody set values in postman
	
	public List<Employee> addAllEmployee(@RequestBody List<Employee> list)
	{
		empService.saveAllEmployee(list);
		return list;
	}
	
	
	@GetMapping("/getone/{id}")
	
	public Employee findOneEmployee(@PathVariable int id)
	{
		Employee e=new Employee();
		try
		
		{
			e= empService.getOneEmployee(id);

		}
		catch(Exception ex)
		{
			System.out.println(ex);
		}
		return e;
		
	}

	@GetMapping("/getAll")

	
	public List<Employee> findAllEmployee() 
	{
		return empService.getAllEmployee();
	}
	
	
	@DeleteMapping("/deletebyid/{id}")
	
	public void deleteById(@PathVariable int id)
	{
		empService.deleteById(id);
	}
	
	@PutMapping("update.")
	
	public Employee updateEmployee(@RequestBody Employee e) 
	{
		return empService.updateEmployee(e);

		
	}
	
	//find by email
	@GetMapping("getemail/{email}")
	public Employee getByEmail(@PathVariable String email)
	{
		return empService.getfindByEmail(email);
	}
	
	//returns names of employees
	@GetMapping("getNames")
	public List<String> getEmployeeNames()
	{		
		return empService.findEmployeeNames();

	}
	
	
}
