package com.symbiosis;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ProjectsSpringEmployeeManagementApplicationTests {

	@Test
	void contextLoads() {
	}

}
