package com.symbiosis.TestJPA;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.Persistence;

import com.model.Employee;

public class TestEmployee 
{

	public static void main(String[] args) 
	{
		EntityManagerFactory emf=Persistence.createEntityManagerFactory("emp");
		
		EntityManager em= emf.createEntityManager();
		
		em.getTransaction().begin();
	
		Employee e1 = new Employee();//import com.model class
		e1.setId(101);
		e1.setName("ajay");
		e1.setSalary(5000);
		
		Employee e2 = new Employee(102,"ravi",6000);
		
		Employee e3 = new Employee(103,"babi",60000);

		//em.persist(e1);//persist :-does not saves data permenent
		//em.persist(e2);
		//em.persist(e3);
		//open sql select*from employee;

		//before find command change in xml file create to update
		//Employee e=em.find(Employee.class, 101);//finds the record at that id
		
		//remove an entity

		//Employee e=em.find(Employee.class, 101);//finds the record at that id
		//em.remove(e);//removes record at id 101
		
		//update 
		
		Employee e=em.find(Employee.class, 101);//finds the record at that id
		e.setName("babya");
		em.getTransaction().commit();//TRANSACTION:- changes in db
		
		
		
		
		
	}

}
