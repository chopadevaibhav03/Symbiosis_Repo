package com.controller;

import java.util.ArrayList;
import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.Persistence;

import com.model.Subject;
import com.model.Teacher;

public class TestOneToMany 
{
	public static void main(String[] args) 
	{
		
	
		EntityManagerFactory emf = Persistence.createEntityManagerFactory("many");
		
		EntityManager em = emf.createEntityManager();
		
		em.getTransaction().begin();		
		
		Subject s1 = new Subject();
		s1.setsId(1);
		s1.setsName("JAVA ");
		
		em.persist(s1);
		
		Subject s2 = new Subject();
		s2.setsId(2);
		s2.setsName("Angular");
		
		em.persist(s2);
		
		Subject s3 = new Subject();
		s3.setsId(3);
		s3.setsName("Software Testing ");
		
		em.persist(s3);
		
		List<Subject> list = new ArrayList<Subject>();
		list.add(s1);
		list.add(s2);
		list.add(s3);
		
		Teacher t1 = new Teacher();
		t1.setId(101);
		t1.setName("kiran Tiwari");
		t1.setList(list);
		
		em.persist(t1);
		
		em.getTransaction().commit();
		
	}
}
