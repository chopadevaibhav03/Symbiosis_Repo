package com.model;

import javax.persistence.Entity;
import javax.persistence.Id;

@Entity
public class Subject 
{
	@Id 
	private int sId ;
	private String sName;
	
		
	public Subject()
	{
		super();
	}

	public Subject(int sId, String sName) 
	{
		super();
		this.sId = sId;
		this.sName = sName;
	}

	public int getsId()
	{
		return sId;
	}

	public void setsId(int sId) 
	{
		this.sId = sId;
	}

	public String getsName() 
	{
		return sName;
	}

	public void setsName(String sName)
	{
		this.sName = sName;
	}
}
