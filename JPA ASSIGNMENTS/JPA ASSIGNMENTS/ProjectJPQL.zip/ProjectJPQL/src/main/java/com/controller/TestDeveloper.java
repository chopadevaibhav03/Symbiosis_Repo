package com.controller;

import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.Persistence;
import javax.persistence.Query;

import com.model.Developer;

public class TestDeveloper 
{

	public static void main(String[] args)
	{
		EntityManagerFactory emf=Persistence.createEntityManagerFactory("dev");

		EntityManager em= emf.createEntityManager();
		
		em.getTransaction().begin();
		
		Developer d1 =  new Developer(101, "sayali",21);
		Developer d2 =  new Developer(102, "janki",22);
		Developer d3 =  new Developer(103, "sau",20);

		em.persist(d1);
		em.persist(d2);
		em.persist(d3);
		em.getTransaction().commit();

			
		//(the select query is created for model class not db )
		
		Query query = em.createQuery("select d.name from Developer d");
		
		/*we want list of names so we write (select d.name from Developer d) in query 
		and for printing the names we created list of <String> .
		*/
		
		List<String> list = query.getResultList();
		
		System.out.println("Names from Develpoer are ");

		for(String s: list)
		{
			System.out.println(s);
		}
		
		Query query1 = em.createQuery("select d.id from Developer d");


		List<Integer> list1 = query1.getResultList();
		
		System.out.println("Id's from Developer are ");

		for(int s: list1)
		{

			System.out.println(s);
		}

		
	}
	

}
