package com.modelAuthor;

import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.NamedQuery;

@Entity

//@NamesQuery :- we give the name to query here name is "find name"

@NamedQuery(name ="find name" , query ="select a.name from Author a")

public class Author
{
	@Id 
	private int id;
	private String name;
	
	
	public Author() 
	{
		super();
	}
	
	
	public Author(int id, String name)
	{
		super();
		this.id = id;
		this.name = name;
	}


	public int getId() 
	{
		return id;
	}


	public void setId(int id) 
	{
		this.id = id;
	}


	public String getName()
	{
		return name;
	}


	public void setName(String name) 
	{
		this.name = name;
	}
	

}
