package com.controllerAuthor;

import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.Persistence;
import javax.persistence.Query;

import com.modelAuthor.Author;

public class TestAuthor
{

	public static void main(String[] args)
	{
		EntityManagerFactory emf=Persistence.createEntityManagerFactory("dev");

		EntityManager em= emf.createEntityManager();
		
		em.getTransaction().begin();
		
		Author a1 =  new Author (1,"janki");
		Author a2 =  new Author (2,"sayali");
		Author a3 =  new Author (3,"sanki");
		
		/*em.persist(a1);
		em.persist(a2);
		em.persist(a3);
		after persist change create -> update*/ 
		
		//criteria query :- it means we apply conditions
		//"select a from Author a" -> replace by  "from Author"
		
		/*
		Query q = em.createQuery("from Author");
		
		List<Author> list =q.getResultList();
		
		System.out.println("Id and Names from Author are");
		for(Author ob: list)
		{
			System.out.println(ob.getId()+" "+ob.getName());
		}
		*/
		
		//count() records form Author
		/*
		Query q = em.createQuery("select count(a) from Author a");
			
		System.out.println("count is ");
		System.out.println(q.getSingleResult());		
		*/
		
		
		//find name = comes from Author Query
		//change createQuery() by CreateNamedQuery()
		//NamedQuery is Static Way Query
		
		
		Query q = em.createNamedQuery("find name" );
		
		List<String> list =q.getResultList();

		System.out.println("@NamedQuery");
		for(String s:list)
		{
			System.out.println(s);
		}
		
		em.getTransaction().commit();


	}

}
