package com.model;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Inheritance;
import javax.persistence.InheritanceType;

@Entity
//@Inheritance(strategy = InheritanceType.SINGLE_TABLE) //creates table including all tables
//@Inheritance(strategy = InheritanceType.JOINED)  //creates different table for each tables and does not allowed duplicate element
@Inheritance(strategy = InheritanceType.TABLE_PER_CLASS)  //creates table for each entity but in parent class there is no table `1duplication of col is there 

public class Employee 
{

	@Id
	@GeneratedValue(strategy = GenerationType.AUTO)
	private int id;
	private String name;
	
	
	public Employee()
	{
		super();
		// TODO Auto-generated constructor stub
	}


	public Employee(int id, String name) 
	{
		super();
		this.id = id;
		this.name = name;
	}


	public int getId() 
	{
		return id;
	}


	public void setId(int id)
	{
		this.id = id;
	}


	public String getName() 
	{
		return name;
	}


	public void setName(String name)
	{
		this.name = name;
	}
	
	
	
	
	
	
}
