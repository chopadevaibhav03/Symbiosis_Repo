package com.controller;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.Persistence;

import com.model.Employee;
import com.model.RegularEmployee;
import com.model.RetiredEmpoyee;

public class TestSingle_Table {

	public static void main(String[] args)
	{

		EntityManagerFactory emf = Persistence.createEntityManagerFactory("emp");
		
		EntityManager em = emf.createEntityManager();
		
		em.getTransaction().begin();
		
		RegularEmployee r1 = new RegularEmployee();
		r1.setName("sayali");
		r1.setSalary(40000);
		
		RetiredEmpoyee re = new RetiredEmpoyee();
		re.setName("Bhargav");
		re.setPension(50000);
		
		
		em.persist(r1);
		em.persist(re);
		
		
		//after execution of single inher. change database from jpainheritance to  jpajoinedinheritance;
		
		//after execution of joinedinheritance change database from jpajoinedinheritance to  jpaclassinheritance;

		em.getTransaction().commit();
	}

}
