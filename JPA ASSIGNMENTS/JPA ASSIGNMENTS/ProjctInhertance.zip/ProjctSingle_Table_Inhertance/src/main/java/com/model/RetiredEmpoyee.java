package com.model;

import javax.persistence.Entity;

@Entity
public class RetiredEmpoyee extends Employee 
{
	private int pension;

	

	public RetiredEmpoyee() {
		super();
		// TODO Auto-generated constructor stub
	}

	public RetiredEmpoyee(int id, String name) {
		super(id, name);
		// TODO Auto-generated constructor stub
	}

	public RetiredEmpoyee(int pension) {
		super();
		this.pension = pension;
	}

	public int getPension() {
		return pension;
	}

	public void setPension(int pension) {
		this.pension = pension;
	}

	
	

}
