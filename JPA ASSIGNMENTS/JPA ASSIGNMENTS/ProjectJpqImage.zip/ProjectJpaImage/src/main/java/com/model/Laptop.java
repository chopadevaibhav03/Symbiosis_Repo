package com.model;

import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Lob;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;
import javax.persistence.Transient;

@Entity //@Entity(name="lap")  we can change the name of class as lap
@Table(name="lap")  //generate table lap
public class Laptop 
{
	@Id
	@GeneratedValue(strategy = GenerationType.AUTO)
	private int id;
	
	@Column(name="lap_name",length =40)   //change the name in db as lap_name  // length=attribute
	private String name ;
	
	private int cost;
	
	@Temporal(TemporalType.DATE)     //with date we get time zone also so when we need only date from 
									 //then use @Temporal entity with TYPE TemporalType.DATE  
	private Date purchasedDate;  //import java.util for Date

	@Lob    //represents following attribute is  "LARGE OBJ TYPE"
	private byte[] image;

	@Transient  
	private int x;
	
	public Laptop()
	{
		super();
		// TODO Auto-generated constructor stub
	}


	public Laptop(int id, String name, int cost, Date purchasedDate, byte[] image) 
	{
		super();
		this.id = id;
		this.name = name;
		this.cost = cost;
		this.purchasedDate = purchasedDate;
		this.image = image;
	}


	public int getId() {
		return id;
	}


	public void setId(int id) {
		this.id = id;
	}


	public String getName() {
		return name;
	}


	public void setName(String name) {
		this.name = name;
	}


	public int getCost() 
	{
		return cost;
	}


	public void setCost(int cost)
	{
		this.cost = cost;
	}


	public Date getPurchasedDate()
	{
		return purchasedDate;
	}


	public void setPurchasedDate(Date purchasedDate)
	{
		this.purchasedDate = purchasedDate;
	}


	public byte[] getImage()
	{
		return image;
	}


	public void setImage(byte[] image) 
	
	{
		this.image = image;
	}


	public int getX() 
	{
		return x;
	}


	public void setX(int x) 
	{
		this.x = x;
	}

	
	
	
	
	
	
	
	
	
}
