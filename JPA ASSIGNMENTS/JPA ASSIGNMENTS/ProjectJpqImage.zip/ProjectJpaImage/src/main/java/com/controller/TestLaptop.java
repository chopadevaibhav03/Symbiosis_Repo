package com.controller;


import java.io.FileInputStream;
import java.io.IOException;
import java.util.Date;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.Persistence;

import com.model.Laptop;

public class TestLaptop
{

	public static void main(String[] args) throws IOException
	{

		EntityManagerFactory emf = Persistence.createEntityManagerFactory("lap");
		
		EntityManager em = emf.createEntityManager();
		
		em.getTransaction().begin();
		
		Laptop l1 = new Laptop();
		l1.setName("DELL");
		l1.setCost(50000);
		l1.setPurchasedDate(new Date());
		
		//save as any  image from net -> go  file copy it and paste it to src/main/java
		
		FileInputStream fis  = new FileInputStream("src/main/java/dell.png");
		
		byte[] data = new byte[fis.available()];  //available = returns size of image in byte
		
		fis.read(data);
		
		l1.setImage(data);
		
		l1.setX(123); //value does not save in DB
		
		em.persist(l1);
		
		em.getTransaction().commit();
		
		
	}

}
