import { Observable } from "rxjs/internal/Observable";

export class Player{

    playerId:number;
    playerName:string;

    constructor(){
        this.playerId=0;
        this.playerName="";
    }
  
}